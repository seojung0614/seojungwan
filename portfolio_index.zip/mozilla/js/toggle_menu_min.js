$(function(){
$('.btn_tgl').click(function(){$('nav').slideToggle(300)})
})