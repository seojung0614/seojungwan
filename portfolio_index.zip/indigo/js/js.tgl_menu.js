$('.tgl_menu').click(function(){
    $('.header nav').slideToggle(300)
});